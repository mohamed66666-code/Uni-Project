import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'constants/app_colors.dart';
import 'services/app_state.dart';
import 'screens/login_screen.dart';
import 'screens/home_screen.dart';
import 'screens/attendance_screen.dart';
import 'screens/news_screen.dart';
import 'screens/restaurant_screen.dart';
import 'screens/trips_screen.dart';
import 'screens/payments_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/schedule_screen.dart';
import 'screens/grades_screen.dart';
import 'screens/library_screen.dart';
import 'screens/exams_screen.dart';
import 'screens/inquiries_screen.dart';
import 'screens/notifications_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const UniversityApp());
}

class UniversityApp extends StatelessWidget {
  const UniversityApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.instance,
      builder: (context, child) {
        final isDark = AppState.instance.isDarkMode;

        final scaffoldBg = isDark ? AppColors.darkScaffold : AppColors.scaffoldBg;
        final cardBg = isDark ? AppColors.darkCard : Colors.white;

        return MaterialApp(
          title: 'بوابة جامعة دمنهور الذكية - Damanhour University',
          debugShowCheckedModeBanner: false,
          locale: const Locale('ar', 'EG'),
          supportedLocales: const [
            Locale('ar', 'EG'),
            Locale('en', 'US'),
          ],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          theme: ThemeData(
            useMaterial3: true,
            fontFamilyFallback: const ['Cairo', 'Segoe UI', 'Arial', 'sans-serif'],
            brightness: isDark ? Brightness.dark : Brightness.light,
            scaffoldBackgroundColor: scaffoldBg,
            colorScheme: ColorScheme.fromSeed(
              seedColor: AppColors.dmuNavy,
              primary: AppColors.dmuNavy,
              secondary: AppColors.dmuGold,
              tertiary: AppColors.dmuRoyal,
              surface: cardBg,
              brightness: isDark ? Brightness.dark : Brightness.light,
            ),
            appBarTheme: AppBarTheme(
              elevation: 0,
              scrolledUnderElevation: 0,
              centerTitle: true,
              backgroundColor: cardBg,
              foregroundColor: isDark ? Colors.white : AppColors.dmuNavy,
              titleTextStyle: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: isDark ? Colors.white : AppColors.dmuNavy,
              ),
              iconTheme: IconThemeData(
                color: isDark ? Colors.white : AppColors.dmuNavy,
              ),
            ),
            cardTheme: CardThemeData(
              elevation: 0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(20),
                side: BorderSide(
                  color: isDark ? AppColors.darkBorder : AppColors.borderSubtle,
                  width: 1.2,
                ),
              ),
              color: cardBg,
            ),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: isDark ? const Color(0xFF13233D) : const Color(0xFFF1F5F9),
              contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide(
                  color: isDark ? AppColors.darkBorder : const Color(0xFFE2E8F0),
                  width: 1,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: const BorderRadius.all(Radius.circular(16)),
                borderSide: const BorderSide(color: AppColors.dmuRoyal, width: 1.8),
              ),
              prefixIconColor: isDark ? AppColors.dmuGoldLight : const Color(0xFF64748B),
              labelStyle: TextStyle(
                color: isDark ? AppColors.darkTextMuted : const Color(0xFF64748B),
                fontSize: 14,
              ),
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                elevation: 0,
                backgroundColor: AppColors.dmuNavy,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                textStyle: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          initialRoute: '/',
          routes: {
            '/': (context) => const LoginScreen(),
            '/home': (context) => const HomeScreen(),
            '/attendance': (context) => const AttendanceScreen(),
            '/news': (context) => const NewsScreen(),
            '/restaurant': (context) => const RestaurantScreen(),
            '/trips': (context) => const TripsScreen(),
            '/payments': (context) => const PaymentsScreen(),
            '/profile': (context) => const ProfileScreen(),
            '/schedule': (context) => const ScheduleScreen(),
            '/grades': (context) => const GradesScreen(),
            '/library': (context) => const LibraryScreen(),
            '/exams': (context) => const ExamsScreen(),
            '/inquiries': (context) => const InquiriesScreen(),
            '/notifications': (context) => const NotificationsScreen(),
          },
        );
      },
    );
  }
}
