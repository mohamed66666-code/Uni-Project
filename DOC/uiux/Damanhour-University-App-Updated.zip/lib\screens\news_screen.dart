import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class NewsArticle {
  final String title;
  final String category;
  final String date;
  final String summary;
  final String fullContent;
  final bool isUrgent;

  NewsArticle({
    required this.title,
    required this.category,
    required this.date,
    required this.summary,
    required this.fullContent,
    this.isUrgent = false,
  });
}

class NewsScreen extends StatefulWidget {
  const NewsScreen({super.key});

  @override
  State<NewsScreen> createState() => _NewsScreenState();
}

class _NewsScreenState extends State<NewsScreen> {
  int _selectedCategoryIndex = 0;

  final List<NewsArticle> _articles = [
    NewsArticle(
      title: 'مجلس جامعة دمنهور يعتمد جداول امتحانات الفصل الدراسي الأول',
      category: 'امتحانات',
      date: 'منذ ساعتين • مجمع الأبعادية',
      isUrgent: true,
      summary: 'اعتمد رئيس جامعة دمنهور الخطة التنظيمية للجان الامتحانات بمجمع الكليات بالأبعادية وكافة المقار.',
      fullContent:
          'أكدت إدارة جامعة دمنهور وكلية الحاسبات والمعلومات جاهزية كافة القاعات والمدرجات والمعامل لاستقبال الطلاب، مع التشديد على ضرورة إحضار بطاقة الرقم القومي والكارنيه الجامعي، والالتزام بالإجراءات التنظيمية المعلنة.',
    ),
    NewsArticle(
      title: 'كلية الحاسبات والمعلومات جامعة دمنهور تطلق هاكاثون الابتكار الرقمي',
      category: 'تدريب',
      date: 'أمس • كلية الحاسبات',
      summary: 'دعوة مفتوحة لطلاب كليات الجامعة للمشاركة بمشروعات الذكاء الاصطناعي والأمن السيبراني بجوائز كبرى.',
      fullContent:
          'يهدف الهاكاثون إلى تشجيع طلاب جامعة دمنهور على بناء حلول برمجية ذكية لخدمة قضايا المجتمع والبيئة وتطوير الخدمات الطلابية، مع توفير إشراف وتوجيه من نخبة من أساتذة الكلية وخبراء الصناعة.',
    ),
    NewsArticle(
      title: 'افتتاح الملاعب الرياضية الجديدة بمجمع الكليات بالأبعادية',
      category: 'أنشطة',
      date: '15 أكتوبر • رعاية الشباب',
      summary: 'انطلاق دوري جامعة دمنهور لكليات المجمعين العلمي والنظري بمشاركة واسعة من الفرق الطلابية.',
      fullContent:
          'افتتحت الإدارة العامة لرعاية الطلاب الملاعب الرياضية المتطورة بعد أعمال التجديد الشاملة، وبدأت التصفيات الأولى في خماسيات كرة القدم وكرة السلة وتنس الطاولة.',
    ),
    NewsArticle(
      title: 'ندوة علمية حول الحوسبة السحابية بالشراكة مع مركز تكنولوجيا المعلومات',
      category: 'ندوات',
      date: '12 أكتوبر • قاعة المؤتمرات',
      summary: 'ندوة لطلاب علوم الحاسب ونظم المعلومات حول أحدث تقنيات السحابة وفرص الشهادات المهنية الدولية.',
      fullContent:
          'تناولت الندوة مسارات التعلم في AWS و Azure، وكيفية بناء مهارات تنافسية تؤهل خريجي جامعة دمنهور لأسواق العمل الإقليمية والدولية بكفاءة واحترافية.',
    ),
  ];

  void _openArticleDetails(NewsArticle article) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => Container(
        padding: const EdgeInsets.all(24),
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey.shade300,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: article.isUrgent
                        ? AppColors.crimsonLight
                        : const Color(0xFFEFF6FF),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    article.category,
                    style: TextStyle(
                      color: article.isUrgent
                          ? AppColors.crimsonDanger
                          : AppColors.dmuNavy,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  article.date,
                  style: TextStyle(color: Colors.grey.shade500, fontSize: 12),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Text(
              article.title,
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.dmuNavy,
                height: 1.35,
              ),
            ),
            const SizedBox(height: 14),
            Text(
              article.fullContent,
              style: TextStyle(
                fontSize: 14,
                height: 1.65,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.dmuNavy,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                onPressed: () => Navigator.pop(ctx),
                child: const Text('إغلاق الخبر'),
              ),
            ),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('أخبار جامعة دمنهور'),
        backgroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Filter Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: Row(
              children: [
                _buildCategoryChip(0, 'كافة الأخبار'),
                const SizedBox(width: 8),
                _buildCategoryChip(1, 'امتحانات'),
                const SizedBox(width: 8),
                _buildCategoryChip(2, 'تدريب وهاكاثون'),
                const SizedBox(width: 8),
                _buildCategoryChip(3, 'أنشطة الجامعة'),
              ],
            ),
          ),

          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              itemCount: _articles.length,
              separatorBuilder: (context, index) => const SizedBox(height: 12),
              itemBuilder: (context, index) {
                final article = _articles[index];
                return InkWell(
                  onTap: () => _openArticleDetails(article),
                  borderRadius: BorderRadius.circular(18),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: article.isUrgent
                            ? const Color(0xFFFCA5A5)
                            : const Color(0xFFE2E8F0),
                        width: article.isUrgent ? 1.5 : 1,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color.fromRGBO(10, 37, 64, 0.04),
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: article.isUrgent
                                    ? AppColors.crimsonLight
                                    : const Color(0xFFEFF6FF),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                article.category,
                                style: TextStyle(
                                  color: article.isUrgent
                                      ? AppColors.crimsonDanger
                                      : AppColors.dmuNavy,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 11,
                                ),
                              ),
                            ),
                            Text(
                              article.date,
                              style: TextStyle(fontSize: 11, color: Colors.grey.shade400),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Text(
                          article.title,
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            color: AppColors.dmuNavy,
                            height: 1.3,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          article.summary,
                          style: TextStyle(fontSize: 12.5, color: Colors.grey.shade600, height: 1.4),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryChip(int index, String label) {
    final isSelected = _selectedCategoryIndex == index;
    return InkWell(
      onTap: () => setState(() => _selectedCategoryIndex = index),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.dmuNavy : Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isSelected ? AppColors.dmuNavy : const Color(0xFFE2E8F0),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 12.5,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.white : const Color(0xFF475569),
          ),
        ),
      ),
    );
  }
}
