import 'package:flutter/material.dart';

/// نظام الألوان الرسمي والموحد لتطبيق جامعة دمنهور (Damanhour University)
class AppColors {
  // الألوان الأساسية لهوية جامعة دمنهور (Navy & Royal Blue)
  static const Color dmuNavy = Color(0xFF0A2540); // كحلي جامعة دمنهور الرسمي
  static const Color dmuNavyDark = Color(0xFF06182B); // كحلي غامق
  static const Color dmuRoyal = Color(0xFF1E3A8A); // أزرق ملكي أكاديمي
  static const Color dmuBlue = Color(0xFF2563EB); // أزرق عصري
  static const Color dmuBlueLight = Color(0xFF60A5FA); // أزرق فاتح

  // اللون الذهبي الأكاديمي لشعار الجامعة والتميز (Academic Gold)
  static const Color dmuGold = Color(0xFFD97706); // ذهبي ملكي
  static const Color dmuGoldLight = Color(0xFFFBBF24); // ذهبي ساطع
  static const Color dmuGoldTint = Color(0xFFFEF3C7); // خلفية ذهبية ناعمة
  static const Color dmuGoldBorder = Color(0xFFFDE68A); // إطار ذهبي ناعم

  // ألوان التفاعل والإشعار (Semantic Colors)
  static const Color emeraldSuccess = Color(0xFF059669); // حضور / تم بنجاح
  static const Color emeraldLight = Color(0xFFD1FAE5);
  static const Color crimsonDanger = Color(0xFFDC2626); // غياب / مستحق / تنبيه
  static const Color crimsonLight = Color(0xFFFEE2E2);
  static const Color amberWarning = Color(0xFFD97706); // قيد المراجعة
  static const Color purpleAccent = Color(0xFF7C3AED); // خدمات خاصة
  static const Color cyanAccent = Color(0xFF0891B2);

  // الخلفيات والأسطح في المظهر النهاري (Light Theme)
  static const Color scaffoldBg = Color(0xFFF8FAFC);
  static const Color cardBg = Colors.white;
  static const Color borderSubtle = Color(0xFFE2E8F0);
  static const Color borderHighlight = Color(0xFFCBD5E1);

  // نصوص وعناوين (Typography Colors)
  static const Color textHeadline = Color(0xFF0A2540);
  static const Color textBody = Color(0xFF334155);
  static const Color textMuted = Color(0xFF64748B);
  static const Color textLight = Color(0xFF94A3B8);

  // المظهر الليلي لهوية جامعة دمنهور (Dark Theme)
  static const Color darkScaffold = Color(0xFF070F1E);
  static const Color darkCard = Color(0xFF0F1E36);
  static const Color darkBorder = Color(0xFF1E3354);
  static const Color darkText = Color(0xFFF1F5F9);
  static const Color darkTextMuted = Color(0xFF94A3B8);

  // التدرجات اللونية الفخمة (Gradients)
  static const LinearGradient heroGradient = LinearGradient(
    colors: [Color(0xFF06182B), Color(0xFF0A2540), Color(0xFF1E3A8A)],
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
  );

  static const LinearGradient brandGradient = LinearGradient(
    colors: [Color(0xFF0A2540), Color(0xFF1E3A8A), Color(0xFF2563EB)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient goldGradient = LinearGradient(
    colors: [Color(0xFFD97706), Color(0xFFF59E0B), Color(0xFFFBBF24)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient drawerHeaderGradient = LinearGradient(
    colors: [Color(0xFF06182B), Color(0xFF0A2540), Color(0xFF1E3A8A)],
    begin: Alignment.topRight,
    end: Alignment.bottomLeft,
  );

  // للتوافق مع الأكواد السابقة
  static const Color primary = dmuNavy;
  static const Color primaryDark = dmuNavyDark;
  static const Color primaryLight = dmuBlue;
  static const Color accent = dmuGold;
  static const Color tealTint = Color(0xFFEFF6FF); // Soft Blue Tint
  static const Color tealBorder = Color(0xFFBFDBFE);
}
