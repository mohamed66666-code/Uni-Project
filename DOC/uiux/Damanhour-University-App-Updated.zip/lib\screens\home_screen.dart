import 'package:flutter/material.dart';
import '../constants/app_colors.dart';
import '../services/app_state.dart';
import '../widgets/dmu_logo.dart';
import '../widgets/service_card.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentNavIndex = 0;

  @override
  Widget build(BuildContext context) {
    final appState = AppState.instance;
    final student = appState.currentStudent;
    final unreadCount = appState.unreadNotificationsCount;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: Row(
          children: [
            const DmuLogo(size: 34),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      Text(
                        'جامعة دمنهور',
                        style: TextStyle(
                          fontSize: 14.5,
                          fontWeight: FontWeight.bold,
                          color: isDark ? Colors.white : AppColors.dmuNavy,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1.5),
                        decoration: BoxDecoration(
                          color: AppColors.dmuGoldTint,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(color: AppColors.dmuGoldBorder, width: 0.8),
                        ),
                        child: const Text(
                          'DMU',
                          style: TextStyle(
                            fontSize: 9.5,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF92400E),
                          ),
                        ),
                      ),
                    ],
                  ),
                  Text(
                    '${student?.name ?? "محمد عبد العال"} • ${student?.faculty ?? "حاسبات ومعلومات"}',
                    style: TextStyle(
                      fontSize: 11,
                      color: isDark ? AppColors.darkTextMuted : const Color(0xFF64748B),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ],
        ),
        actions: [
          // Wallet Balance Pill
          GestureDetector(
            onTap: () => Navigator.pushNamed(context, '/payments'),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF1E3354) : const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isDark ? const Color(0xFF2E4D79) : const Color(0xFFBFDBFE),
                ),
              ),
              child: Row(
                children: [
                  const Icon(Icons.account_balance_wallet_rounded, size: 14, color: Color(0xFFD97706)),
                  const SizedBox(width: 4),
                  Text(
                    '${appState.walletBalance.toStringAsFixed(0)} ج.م',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: isDark ? Colors.white : AppColors.dmuNavy,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          // Notifications Bell with Badge
          IconButton(
            icon: Stack(
              children: [
                Icon(
                  Icons.notifications_outlined,
                  size: 24,
                  color: isDark ? Colors.white : AppColors.dmuNavy,
                ),
                if (unreadCount > 0)
                  Positioned(
                    top: 2,
                    right: 2,
                    child: Container(
                      padding: const EdgeInsets.all(3.5),
                      decoration: const BoxDecoration(
                        color: AppColors.crimsonDanger,
                        shape: BoxShape.circle,
                      ),
                      child: Text(
                        '$unreadCount',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            onPressed: () => Navigator.pushNamed(context, '/notifications'),
          ),
          const SizedBox(width: 4),
        ],
      ),
      drawer: Drawer(
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  Container(
                    padding: const EdgeInsets.fromLTRB(16, 44, 16, 20),
                    decoration: const BoxDecoration(
                      gradient: AppColors.drawerHeaderGradient,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const DmuLogo(size: 54),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'جامعة دمنهور',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                  const Text(
                                    'DAMANHOUR UNIVERSITY',
                                    style: TextStyle(
                                      color: Color(0xFFFBBF24),
                                      fontSize: 10,
                                      fontWeight: FontWeight.w600,
                                      letterSpacing: 0.8,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    student?.faculty ?? 'كلية الحاسبات والمعلومات',
                                    style: const TextStyle(
                                      color: Colors.white70,
                                      fontSize: 11.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: Colors.white.withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: Colors.white.withValues(alpha: 0.15),
                            ),
                          ),
                          child: Row(
                            children: [
                              const CircleAvatar(
                                radius: 18,
                                backgroundColor: Color(0xFFFBBF24),
                                child: Icon(Icons.person, color: Color(0xFF0A2540), size: 22),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      student?.name ?? 'محمد عبد العال',
                                      style: const TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 13,
                                      ),
                                    ),
                                    Text(
                                      'كود الطالب: ${student?.id ?? "20241050"}',
                                      style: const TextStyle(color: Colors.white70, fontSize: 11),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.calendar_month_rounded, color: Color(0xFF2563EB)),
                    title: const Text('الجدول الدراسي الأسبوعي'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/schedule');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.qr_code_scanner_rounded, color: Color(0xFF059669)),
                    title: const Text('تسجيل الحضور والغياب (QR)'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/attendance');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.grade_rounded, color: Color(0xFFD97706)),
                    title: const Text('النتائج والسجل الأكاديمي'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/grades');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.menu_book_rounded, color: Color(0xFF0891B2)),
                    title: const Text('المكتبة الرقمية والمقررات'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/library');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.assignment_turned_in_rounded, color: Color(0xFFDC2626)),
                    title: const Text('جدول الامتحانات ورقم الجلوس'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/exams');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.account_balance_wallet_rounded, color: Color(0xFF16A34A)),
                    title: const Text('سداد المصروفات والرسوم'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/payments');
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.support_agent_rounded, color: Color(0xFF7C3AED)),
                    title: const Text('الشكاوى والمقترحات والطلبات'),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamed(context, '/inquiries');
                    },
                  ),
                  const Divider(),
                  ListTile(
                    leading: const Icon(Icons.dark_mode_outlined, color: AppColors.dmuNavy),
                    title: const Text('المظهر الليلي (Dark Mode)'),
                    trailing: Switch.adaptive(
                      value: appState.isDarkMode,
                      activeTrackColor: AppColors.dmuRoyal,
                      onChanged: (val) {
                        appState.toggleDarkMode(val);
                      },
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.logout_rounded, color: AppColors.crimsonDanger),
                    title: const Text('تسجيل الخروج', style: TextStyle(color: AppColors.crimsonDanger)),
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
                    },
                  ),
                ],
              ),
            ),
            // Drawer Footer
            Container(
              padding: const EdgeInsets.all(16),
              alignment: Alignment.center,
              child: Text(
                'بوابة جامعة دمنهور الذكية v2.0\nمركز تقنية المعلومات والاتصالات',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 10.5, color: Colors.grey.shade500),
              ),
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 14.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Damanhour University Academic Hero Banner
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: AppColors.heroGradient,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: const Color(0xFFF59E0B).withValues(alpha: 0.3), width: 1.2),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(10, 37, 64, 0.28),
                    blurRadius: 20,
                    offset: Offset(0, 8),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.white.withValues(alpha: 0.2)),
                        ),
                        child: const Row(
                          children: [
                            Icon(Icons.school, size: 13, color: Color(0xFFFBBF24)),
                            SizedBox(width: 5),
                            Text(
                              'جامعة دمنهور • المحاضرة القادمة',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 11.5,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFF059669).withValues(alpha: 0.28),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: const Color(0xFF34D399),
                            width: 1,
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.star, size: 12, color: Color(0xFFFBBF24)),
                            const SizedBox(width: 4),
                            Text(
                              'GPA: ${appState.calculatedGpa.toStringAsFixed(2)}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11.5,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  const Text(
                    'نظم إدارة قواعد البيانات (DBMS)',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'مبنى كلية الحاسبات والمعلومات • معمل 5 • 11:30 ص',
                    style: TextStyle(color: Colors.white70, fontSize: 12.5),
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.white,
                            foregroundColor: AppColors.dmuNavy,
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            elevation: 0,
                            textStyle: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          onPressed: () => Navigator.pushNamed(context, '/attendance'),
                          icon: const Icon(Icons.qr_code_scanner, size: 17, color: AppColors.dmuRoyal),
                          label: const Text('تسجيل الحضور QR'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withValues(alpha: 0.16),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                            side: BorderSide(color: Colors.white.withValues(alpha: 0.25)),
                          ),
                          elevation: 0,
                          textStyle: const TextStyle(
                            fontSize: 12.5,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        onPressed: () => Navigator.pushNamed(context, '/schedule'),
                        child: const Text('الجدول الأسبوعي'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Quick Academic Shortcuts Row
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildQuickPill(
                    icon: Icons.calendar_month_rounded,
                    label: 'جدولي اليومي',
                    color: const Color(0xFF1E3A8A),
                    onTap: () => Navigator.pushNamed(context, '/schedule'),
                  ),
                  const SizedBox(width: 8),
                  _buildQuickPill(
                    icon: Icons.analytics_outlined,
                    label: 'النتائج والتقديرات',
                    color: const Color(0xFF059669),
                    onTap: () => Navigator.pushNamed(context, '/grades'),
                  ),
                  const SizedBox(width: 8),
                  _buildQuickPill(
                    icon: Icons.menu_book_rounded,
                    label: 'المكتبة والمقررات',
                    color: const Color(0xFFD97706),
                    onTap: () => Navigator.pushNamed(context, '/library'),
                  ),
                  const SizedBox(width: 8),
                  _buildQuickPill(
                    icon: Icons.assignment_outlined,
                    label: 'رقم الجلوس',
                    color: const Color(0xFFDC2626),
                    onTap: () => Navigator.pushNamed(context, '/exams'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),

            // Services Grid Title
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    Container(
                      width: 4,
                      height: 18,
                      decoration: BoxDecoration(
                        color: AppColors.dmuGold,
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      'بوابة الخدمات الأكاديمية والطلابية',
                      style: TextStyle(
                        fontSize: 16.5,
                        fontWeight: FontWeight.bold,
                        color: isDark ? Colors.white : AppColors.dmuNavy,
                      ),
                    ),
                  ],
                ),
                Text(
                  '10 خدمات',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade500),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Full Comprehensive Grid
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.15,
              children: [
                ServiceCard(
                  title: 'حضور المحاضرات',
                  subtitle: 'تسجيل وسجل الغياب',
                  icon: Icons.qr_code_scanner_rounded,
                  accentColor: const Color(0xFF1E3A8A),
                  badgeText: 'محدث',
                  onTap: () => Navigator.pushNamed(context, '/attendance'),
                ),
                ServiceCard(
                  title: 'الجدول الدراسي',
                  subtitle: 'مواعيد وقاعات الأسبوع',
                  icon: Icons.calendar_month_rounded,
                  accentColor: const Color(0xFF2563EB),
                  onTap: () => Navigator.pushNamed(context, '/schedule'),
                ),
                ServiceCard(
                  title: 'النتائج والتقديرات',
                  subtitle: 'سجل الدرجات والـ GPA',
                  icon: Icons.grade_rounded,
                  accentColor: const Color(0xFF059669),
                  badgeText: '3.65',
                  onTap: () => Navigator.pushNamed(context, '/grades'),
                ),
                ServiceCard(
                  title: 'المكتبة والمقررات',
                  subtitle: 'مذكرات ومراجع PDF',
                  icon: Icons.menu_book_rounded,
                  accentColor: const Color(0xFFD97706),
                  onTap: () => Navigator.pushNamed(context, '/library'),
                ),
                ServiceCard(
                  title: 'الامتحانات ولجنتي',
                  subtitle: 'رقم الجلوس والمقر',
                  icon: Icons.assignment_turned_in_rounded,
                  accentColor: const Color(0xFFDC2626),
                  badgeText: 'جديد',
                  onTap: () => Navigator.pushNamed(context, '/exams'),
                ),
                ServiceCard(
                  title: 'المصروفات والرسوم',
                  subtitle: 'سداد وفواتير إلكترونية',
                  icon: Icons.account_balance_wallet_rounded,
                  accentColor: const Color(0xFF0D9488),
                  badgeText: 'مستحق',
                  onTap: () => Navigator.pushNamed(context, '/payments'),
                ),
                ServiceCard(
                  title: 'مطعم الكلية',
                  subtitle: 'وجبات اليوم والاشتراك',
                  icon: Icons.restaurant_rounded,
                  accentColor: const Color(0xFFEA580C),
                  onTap: () => Navigator.pushNamed(context, '/restaurant'),
                ),
                ServiceCard(
                  title: 'الرحلات والأنشطة',
                  subtitle: 'معسكرات ورحلات الجامعة',
                  icon: Icons.explore_rounded,
                  accentColor: const Color(0xFF4F46E5),
                  onTap: () => Navigator.pushNamed(context, '/trips'),
                ),
                ServiceCard(
                  title: 'الشكاوى والطلبات',
                  subtitle: 'تذاكر ودعم الطلاب',
                  icon: Icons.support_agent_rounded,
                  accentColor: const Color(0xFF7C3AED),
                  onTap: () => Navigator.pushNamed(context, '/inquiries'),
                ),
                ServiceCard(
                  title: 'أخبار جامعة دمنهور',
                  subtitle: 'البيانات والإعلانات',
                  icon: Icons.campaign_rounded,
                  accentColor: const Color(0xFF0284C7),
                  badgeText: '3 جديدة',
                  onTap: () => Navigator.pushNamed(context, '/news'),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentNavIndex,
        selectedItemColor: AppColors.dmuNavy,
        unselectedItemColor: Colors.grey.shade400,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
        selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
        unselectedLabelStyle: const TextStyle(fontSize: 12),
        onTap: (index) {
          setState(() => _currentNavIndex = index);
          if (index == 1) Navigator.pushNamed(context, '/schedule');
          if (index == 2) Navigator.pushNamed(context, '/grades');
          if (index == 3) Navigator.pushNamed(context, '/profile');
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home_rounded),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.calendar_month_rounded),
            label: 'الجدول',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.grade_rounded),
            label: 'النتائج',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person_rounded),
            label: 'حسابي',
          ),
        ],
      ),
    );
  }

  Widget _buildQuickPill({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withValues(alpha: 0.22)),
        ),
        child: Row(
          children: [
            Icon(icon, size: 16, color: color),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
