import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

/// الشعار الرسمي الأكاديمي لجامعة دمنهور (Damanhour University Emblem)
class DmuLogo extends StatelessWidget {
  final double size;
  final bool showText;
  final bool isDark;
  final Color? textColor;

  const DmuLogo({
    super.key,
    this.size = 64,
    this.showText = false,
    this.isDark = false,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
              colors: [
                Color(0xFF0A2540),
                Color(0xFF1E3A8A),
                Color(0xFF0D3B66),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            border: Border.all(
              color: const Color(0xFFF59E0B),
              width: size * 0.04,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF0A2540).withValues(alpha: 0.35),
                blurRadius: size * 0.2,
                offset: Offset(0, size * 0.08),
              ),
            ],
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              // Outer decorative golden ring
              Container(
                margin: EdgeInsets.all(size * 0.06),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xFFFBBF24).withValues(alpha: 0.4),
                    width: 1,
                  ),
                ),
              ),
              // Inner Academic Graphic (Cap + Book + Stars)
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.school_rounded,
                    color: const Color(0xFFFBBF24),
                    size: size * 0.38,
                  ),
                  SizedBox(height: size * 0.02),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.star, color: const Color(0xFFF59E0B), size: size * 0.09),
                      SizedBox(width: size * 0.02),
                      Text(
                        'DMU',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: size * 0.15,
                          letterSpacing: 0.5,
                        ),
                      ),
                      SizedBox(width: size * 0.02),
                      Icon(Icons.star, color: const Color(0xFFF59E0B), size: size * 0.09),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
        if (showText) ...[
          const SizedBox(height: 12),
          Text(
            'جـامـعـة دمـنـهـور',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: textColor ?? (isDark ? Colors.white : AppColors.dmuNavy),
              letterSpacing: -0.3,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            'DAMANHOUR UNIVERSITY • EST. 2010',
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.2,
              color: const Color(0xFFD97706),
            ),
          ),
        ],
      ],
    );
  }
}
